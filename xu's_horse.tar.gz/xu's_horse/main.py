# coding: utf-8
import sys
import os
from screenshot import screen_shot

def main( pic_name,  pic_type='png'):

    screen_shot(pic_name, pic_type)

if __name__ == '__main__':
    pic_num = 0
    while True:
        pic_num += 1
        main( "shot"+str(pic_num))
